@extends('layouts.new')

@section('content')

<div id="sj-twocolumns" class="sj-twocolumns">
	<div class="container">
		<div class="row">
			<div class="col-12 col-sm-12 col-md-8 col-lg-9">
				<div id="sj-content" class="sj-content">
				<!--************************************
						Editor's Pick Start
				*************************************-->
					<section class="sj-haslayout sj-sectioninnerspace">
						<div class="sj-borderheading">
							<h3>Latest Articles</h3>
							<a class="sj-btnview" href="javascript:void(0);">View All</a>
						</div>
						<div id="sj-editorchoiceslider" class="sj-editorchoiceslider sj-editorschoice owl-carousel">
							<div class="item">
								<article class="sj-post sj-editorchoice">
									<figure class="sj-postimg">
										<img src="{{ asset('theme/images/editorchoice/img-01.jpg') }}" alt="image description">
									</figure>
									<div class="sj-postcontent">
										<div class="sj-head">
											<span class="sj-username"><a href="javascript:void(0);">Hillary Farnham</a></span>
											<h3><a href="javascript:void(0);">Toward Better-Quality Compounded Drugs — An Update form</a></h3>
										</div>
										<div class="sj-description">
											<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco...</p>
										</div>
										<a class="sj-btn" href="javascript:void(0);">View Full Article</a>
									</div>
								</article>
								<article class="sj-post sj-editorchoice">
									<figure class="sj-postimg">
										<img src="{{ asset('theme/images/editorchoice/img-02.jpg') }}" alt="image description">
									</figure>
									<div class="sj-postcontent">
										<div class="sj-head">
											<span class="sj-username"><a href="javascript:void(0);">Coleman Hoff</a></span>
											<h3><a href="javascript:void(0);">Toward Better-Quality Compounded Drugs</a></h3>
										</div>
										<div class="sj-description">
											<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco...</p>
										</div>
										<a class="sj-btn" href="javascript:void(0);">View Full Article</a>
									</div>
								</article>
								<article class="sj-post sj-editorchoice">
									<figure class="sj-postimg">
										<img src="{{ asset('theme/images/editorchoice/img-03.jpg') }}" alt="image description">
									</figure>
									<div class="sj-postcontent">
										<div class="sj-head">
											<span class="sj-username"><a href="javascript:void(0);">Frederica Kinnaird</a></span>
											<h3><a href="javascript:void(0);">A Milestone for CART Cells &amp; Treatment</a></h3>
										</div>
										<div class="sj-description">
											<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco...</p>
										</div>
										<a class="sj-btn" href="javascript:void(0);">View Full Article</a>
									</div>
								</article>
							</div>
							<div class="item">
								<article class="sj-post sj-editorchoice">
									<figure class="sj-postimg">
										<img src="{{ asset('theme/images/editorchoice/img-01.jpg') }}" alt="image description">
									</figure>
									<div class="sj-postcontent">
										<div class="sj-head">
											<span class="sj-username"><a href="javascript:void(0);">Hillary Farnham</a></span>
											<h3><a href="javascript:void(0);">Toward Better-Quality Compounded Drugs — An Update form</a></h3>
										</div>
										<div class="sj-description">
											<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco...</p>
										</div>
										<a class="sj-btn" href="javascript:void(0);">View Full Article</a>
									</div>
								</article>
								<article class="sj-post sj-editorchoice">
									<figure class="sj-postimg">
										<img src="{{ asset('theme/images/editorchoice/img-02.jpg') }}" alt="image description">
									</figure>
									<div class="sj-postcontent">
										<div class="sj-head">
											<span class="sj-username"><a href="javascript:void(0);">Coleman Hoff</a></span>
											<h3><a href="javascript:void(0);">Toward Better-Quality Compounded Drugs</a></h3>
										</div>
										<div class="sj-description">
											<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco...</p>
										</div>
										<a class="sj-btn" href="javascript:void(0);">View Full Article</a>
									</div>
								</article>
								<article class="sj-post sj-editorchoice">
									<figure class="sj-postimg">
										<img src="{{ asset('theme/images/editorchoice/img-03.jpg') }}" alt="image description">
									</figure>
									<div class="sj-postcontent">
										<div class="sj-head">
											<span class="sj-username"><a href="javascript:void(0);">Frederica Kinnaird</a></span>
											<h3><a href="javascript:void(0);">A Milestone for CART Cells &amp; Treatment</a></h3>
										</div>
										<div class="sj-description">
											<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco...</p>
										</div>
										<a class="sj-btn" href="javascript:void(0);">View Full Article</a>
									</div>
								</article>
							</div>
							<div class="item">
								<article class="sj-post sj-editorchoice">
									<figure class="sj-postimg">
										<img src="{{ asset('theme/images/editorchoice/img-01.jpg') }}" alt="image description">
									</figure>
									<div class="sj-postcontent">
										<div class="sj-head">
											<span class="sj-username"><a href="javascript:void(0);">Hillary Farnham</a></span>
											<h3><a href="javascript:void(0);">Toward Better-Quality Compounded Drugs — An Update form</a></h3>
										</div>
										<div class="sj-description">
											<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco...</p>
										</div>
										<a class="sj-btn" href="javascript:void(0);">View Full Article</a>
									</div>
								</article>
								<article class="sj-post sj-editorchoice">
									<figure class="sj-postimg">
										<img src="{{ asset('theme/images/editorchoice/img-02.jpg') }}" alt="image description">
									</figure>
									<div class="sj-postcontent">
										<div class="sj-head">
											<span class="sj-username"><a href="javascript:void(0);">Coleman Hoff</a></span>
											<h3><a href="javascript:void(0);">Toward Better-Quality Compounded Drugs</a></h3>
										</div>
										<div class="sj-description">
											<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco...</p>
										</div>
										<a class="sj-btn" href="javascript:void(0);">View Full Article</a>
									</div>
								</article>
								<article class="sj-post sj-editorchoice">
									<figure class="sj-postimg">
										<img src="{{ asset('theme/images/editorchoice/img-03.jpg') }}" alt="image description">
									</figure>
									<div class="sj-postcontent">
										<div class="sj-head">
											<span class="sj-username"><a href="javascript:void(0);">Frederica Kinnaird</a></span>
											<h3><a href="javascript:void(0);">A Milestone for CART Cells &amp; Treatment</a></h3>
										</div>
										<div class="sj-description">
											<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco...</p>
										</div>
										<a class="sj-btn" href="javascript:void(0);">View Full Article</a>
									</div>
								</article>
							</div>
						</div>
					</section>
				<!--************************************
						Editor's Pick End
				*************************************-->
				</div>
			</div>
			<div class="col-12 col-sm-12 col-md-4 col-lg-3">
				<aside id="sj-sidebar" class="sj-sidebar">
					<div class="sj-widget sj-widgetsearch">
						<div class="sj-widgetcontent">
							<form class="sj-formtheme sj-formsearch">
								<fieldset>
									<input type="search" name="search" class="form-control" placeholder="Search here">
									<button type="submit" class="sj-btnsearch"><i class="lnr lnr-magnifier"></i></button>
								</fieldset>
							</form>
						</div>
					</div>


                    <div class="sj-widget sj-widgetadd">
                        <div class="sj-widgetcontent">
                            <figure class="sj-addimage"><a href="javascript:void(0);"><img src="{{ asset('theme/images/we-are-cross-of-member.jpg') }}" alt="image description"></a></figure>
                        </div>
                    </div>

					<div class="sj-widget sj-widgetnoticeboard">
						<div class="sj-widgetheading">
							<h3>Notice Board</h3>
						</div>
						<div class="sj-widgetcontent">
							<ul>
								<li><a href="javascript:void(0);">Adipisicing elitaium sed dotas eiusm tempor incididunt utae labore etiate dolore magna aliqua enim.</a></li>
								<li><a href="javascript:void(0);">Labore etiat dolore magna aliquaen ad minim veniam.</a></li>
								<li><a href="javascript:void(0);">Duis aute irure dolor in reprehender</a></li>
							</ul>
						</div>
					</div>
				</aside>
			</div>
		</div>
	</div>
</div>
@endsection

@section('homebanner')
	<div id="sj-homebanner" class="sj-homebanner">
		<div class="container">
			<div class="row">

				<div class="col-12 col-sm-12 col-md-3 col-lg-3">
					<nav class="sj-bannersidebar">
						<ul>
							<li class="active"><a href="{{ url('/') }}">Home</a></li>
							<li><a href="{{ url('/subscription-and-advertisement-policy') }}">About</a></li>
							<li><a href="{{ url('/editorial-board') }}">Editorial Board</a></li>
							<li><a href="{{ url('/author/start-submission') }}">Submit Article</a></li>
							<li><a href="{{ url('/instructions-to-authors') }}">Author Guideline</a></li>
							<li><a href="{{ url('/#sj-content') }}">Journal Archive</a></li>
							<li><a href="http://baes.com.bd/" target="_blank">BAES (Society Page)</a></li>
							<li><a href="{{ url('/necessary-information-bjee') }}">Contacts</a></li>
						</ul>
					</nav>
				</div>
				<div class="col-12 col-sm-12 col-md-5 col-lg-5">
					<div class="sj-bannercontent">
						<h1><span>Welcome to the</span>Bangladesh Journal<span>Of Extension Education</span></h1>
						<div class="sj-description">
							<p>Consectetur adipisicing elit sedaui sedaui labore quis nostrud exercitation... <a href="javascript:void(0);">Read more</a></p>
						</div>
					</div>

				</div>
				<div class="col-12 col-sm-12 col-md-4 col-lg-4">
					<div class="sj-postbook">
						<figure class="sj-featureimg">
							<a class="sj-btnvideo" href="javascript:void(0);" style="display: none;"><i class="lnr lnr-film-play"></i><span>Watch Video Documentary</span></a>
							<div class="sj-bookimg">
								<div class="sj-frontcover"><img src="{{ asset('theme/images/journal-cover-photo.jpg') }}" alt="image description"></div>
							</div>
						</figure>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection

@section('content1')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-12">
			@guest
			<div class="card">
				<div class="card-header">Journal Project</div>

				<div class="card-body">
					<a href="{{ route('login') }}"> Log In Now!</a>
				</div>
			</div>
			@else
			<div class="card">
				<div class="card-header">Journal Project</div>
				<div class="card-body">
					@if (session('status'))
					<div class="alert alert-success" role="alert">
						{{ session('status') }}
					</div>
					@endif
					Hi {{ Auth::user()->name }}; you are logged in as @foreach (Auth::user()->getRoleNames() as $role)
					{{ $role }}
					@endforeach
				</div>
			</div>
			@endguest
		</div>
	</div>
</div>
@endsection

@section('js')
<script src="{{ asset('theme/js/owl.carousel.min.js') }}"></script>
@endsection