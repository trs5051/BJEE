@extends('layouts.new')

@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<strong></strong>
					
				</div>
				<div class="card-body">
					<table class="table table-striped">
						<thead class="thead-dark">
							<tr>
								<th>Reviewer Id</th>
								<th>Name</th>
								<th>Review Details</th>
							</tr>

						</thead>
						<tbody>

							<tr>
								<td> - </td>
								<td> - </td>
								<td> - </td>
							</tr>


						</tbody>
					</table>
				</div>
				<div class="card-footer">
				
				</div>
			</div>


		</div>

	</div>
</div>
@endsection