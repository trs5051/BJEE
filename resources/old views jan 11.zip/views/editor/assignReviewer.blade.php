@extends('layouts.new')

@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					Assign Reviewers for Submissions
					<a class="float-right btn btn-sm btn-outline-dark" href="{{ route('editor.addNewReviewer') }}">Add
						New Reviewer</a>
				</div>
				<div class="card-body">

					<h3>Reviewers Assigned</h3>

					<table class="table">
						<thead class="thead-dark">
							<tr>
								<th>Review Id</th>
								<th>Name</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							@forelse ($reviewers as $reviewer)
							<tr>

								<td>{{ $reviewer->id }}</td>
								<td>{{ $reviewer->name }}</td>
								<td>
									
									
									@if (in_array($reviewer->id, $current_reviewer))

									@if ($current_reviewer_status[$reviewer->id]->accepted === null )
									Review has not reponded yet
									@endif
									@if ($current_reviewer_status[$reviewer->id]->accepted === 1 )
									Review has accepted to review.									
									@endif
									@if ($current_reviewer_status[$reviewer->id]->accepted === 0 )
									Review has rejected
									@endif

									@else
									Reviewer not Assigned to this Submission
									@endif
									
								</td>
							</tr>
							@empty

							@endforelse
						</tbody>
					</table>
					<hr>

					<h3>Assign Reviewers for <strong>{{ $submission->title }}</strong> Submission</h3>
					<form method="POST" action="{{ route('editor.assignReviewerPost', $submission->id) }}">
						@csrf
						@foreach ($reviewers as $reviewer)

						<div class="form-group">
							@if (in_array($reviewer->id, $current_reviewer))

							<div class="custom-control custom-checkbox">
								<input disabled checked type="checkbox" class="custom-control-input"
									id="reviewer[{{ $reviewer->id }}]">
								<label class="custom-control-label" for="reviewer[{{ $reviewer->id }}]">
									{{ $reviewer->name }} -
									@if ($current_reviewer_status[$reviewer->id]->accepted === null )
									not reponded yet.
									@endif
									@if ($current_reviewer_status[$reviewer->id]->accepted === 1 )
									accepted.

									@endif
									@if ($current_reviewer_status[$reviewer->id]->accepted === 0 )
									rejected.
									@endif
								</label>
							</div>

							@else

							<div class="custom-control custom-checkbox">
								<input type="checkbox" class="custom-control-input"
									id="reviewer[{{ $reviewer->id }}]['id']"
									name="reviewer[{{ $reviewer->id }}][selected]">
								<label class="custom-control-label" for="reviewer[{{ $reviewer->id }}]['id']">
									{{  $reviewer->name }}
								</label>
								<label class="label" for="reviewer[{{ $reviewer->id }}]['date']">
									Set last day to review
									<input value="{!! $defaultDate  !!}" class="" type="date"
										name="reviewer[{{ $reviewer->id }}][date]"
										id="reviewer[{{ $reviewer->id }}]['date']">
								</label>
							</div>

							@endif

						</div>
						@endforeach
						<div class="form-group">
							<button type="submit" class="btn btn-primary">Assign Selected Reviewers</button>
						</div>
					</form>

				</div>

			</div>
		</div>

	</div>
</div>
</div>
</div>
@endsection