<ul>
	

	@auth
	@role('author')
	<li class="menu-item-has-children page_item_has_children">
		<a href="javascript:void(0);">Author Dashboard</a>
		<ul class="sub-menu">
			<li><a href="{{ route('author') }}">Journal Submission</a></li>
			<li><a href="{{ route('startSubmission') }}">Create Submission</a></li>
		</ul>
	</li>
	@endrole

	@role('editor')
	<li class="menu-item-has-children page_item_has_children">
		<a href="javascript:void(0);">Editor Dashboard</a>
		<ul class="sub-menu">
			<li><a href="{{ route('editor.submissions') }}">Submissions</a></li>
			<li><a href="{{ route('editor.reviewers') }}">Manage Reviewer</a></li>
		</ul>
	</li>
	@endrole

	@role('reviewer')
	<li class="menu-item-has-children page_item_has_children">
		<a href="javascript:void(0);">Reviewer Dashboard</a>
		<ul class="sub-menu">
			<li><a href="{{ route('reviewer.submissions') }}">Submissions To Review</a></li>
		</ul>
	</li>	
	@endrole

	@role('superadmin')
	<li class="menu-item-has-children page_item_has_children">
		<a href="javascript:void(0);">Admin Dashboard</a>
		<ul class="sub-menu">
			<li><a href="{{ route('editor.submissions') }}">Submissions</a></li>
			<li><a href="{{ route('admin.users') }}">Manage Users</a></li>
		</ul>
	</li>
	@endrole

	@else


	<li class="menu-item-has-children page_item_has_children">
		<a href="javascript:void(0);">Articles</a>
		<ul class="sub-menu">
			<li><a href="#">Articles</a></li>
			<li><a href="#">Aticle List</a></li>
			<li><a href="#">Article Detail</a></li>
			<li><a href="#">Submit Article</a></li>
		</ul>
	</li>
	<li class="menu-item-has-children page_item_has_children">
		<span class="sj-tagnew">New</span>
		<a href="javascript:void(0);">Issues</a>
		<ul class="sub-menu">
			<li><a href="#">Issues Weeks</a></li>
			<li><a href="#">Issues Years</a></li>
		</ul>
	</li>
	<li class="menu-item-has-children page_item_has_children">
		<a href="javascript:void(0);">Pages</a>
		<ul class="sub-menu">
			<li class="menu-item-has-children page_item_has_children">
				<a href="javascript:void(0);">News</a>
				<ul class="sub-menu">
					<li><a href="#">News Grid</a></li>
					<li><a href="#">News List</a></li>
					<li><a href="#">News Detail</a></li>
				</ul>
			</li>
			<li class="menu-item-has-children page_item_has_children">
				<a href="javascript:void(0);">Manage User</a>
				<ul class="sub-menu">
					<li><a href="#">Manage User</a></li>
					<li><a href="#">Manage Editions</a></li>
				</ul>
			</li>
			<li class="menu-item-has-children page_item_has_children">
				<a href="javascript:void(0);">Settings</a>
				<ul class="sub-menu">
					<li><a href="#">Account Settings</a></li>
					<li><a href="#">General Settings</a></li>
				</ul>
			</li>
			<li><a href="#">Author Guideline</a></li>
			<li><a href="#">Under Review</a></li>
			<li><a href="#">Add Templates</a></li>
			<li><a href="#">Checkout</a></li>
			<li class="menu-item-has-children page_item_has_children">
				<a href="javascript:void(0);">Login</a>
				<ul class="sub-menu">
					<li><a href="#">Login Register</a></li>
					<li><a href="#">Login Register V Two</a></li>
				</ul>
			</li>
			<li><a href="#">404 Error</a></li>
			<li><a href="#">Coming Soon</a></li>
		</ul>
	</li>

	@endauth


	{{-- <li>
		<a href="#">About us</a>
	</li> --}}

</ul>