@extends('layouts.new')

@section('content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-12">
			<h1>404</h1>
		</div>
	</div>
</div>
@endsection