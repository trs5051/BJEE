{{ asset($img) }}
<img src="{{ asset($img) }}" alt="" title="">