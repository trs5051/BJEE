@component('mail::message')
# Review Request
Hello {{ $reviewerName ?? '' }}

You have been invited to review a journal submission,

Submission details;
<strong>Title {{ $submissionTitle ?? ' - ' }}</strong>

The last date to confirm is {{ $expireDate ?? 'December 31, 2019' }}.

Log in to your account or click the buttons below to accept or reject invation to review.

@component('mail::button', ['url' => (route('reviewer.reviewerAccepted' , $reviewerId))])
Accept to Review
@endcomponent

@component('mail::button', ['url' => (route('reviewer.reviewerDeclined' , $reviewerId))])
Reject to Review
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent